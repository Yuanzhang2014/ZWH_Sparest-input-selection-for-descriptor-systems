function Rowindx=FindInvertibleSubmax(A) % find the row indix of an invertible submatrix from matrix A
% supprose row(A)>=column(A);
[rowlength,collength]=size(A);
if rowlength<collength
    A=A';
end
[rowlength,collength]=size(A);


randomindx=randperm(rowlength);
randomindx=randomindx(1:collength);
while(rank(A(randomindx,:))<collength)
randomindx=randperm(rowlength);
randomindx=randomindx(1:collength);
end
Rowindx=randomindx;

