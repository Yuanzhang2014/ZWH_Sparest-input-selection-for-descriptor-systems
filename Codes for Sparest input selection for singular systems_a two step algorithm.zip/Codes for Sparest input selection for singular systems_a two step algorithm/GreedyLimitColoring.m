function [ColorMatch,NumOfColorNodeMatch]=GreedyLimitColoring(G,L,Hi)
%%%G is a squre matrix while '1' in (i,j) reprensents an
%%%edge
%%%L is the number of limited coloring
%%Here is an example.
% clear
% ColorGraphConstraint=[     0     0     0     1
%      0     0     1     1
%      0     1     0     1
%      1     1     1     0];
% CollectionHi=[1 0 0;1 2 3;1 4 5;4 1 2]; % The last rows must be zero, the
% dimension is number of distinct modes x d_max   the last rows are zore; 
% i-th row j-th column = 1 implies that j \in h_i.
% L=2; Hi=CollectionHi
% G=ColorGraphConstraint;

%  Another example: G =
% 
%      0     1     1     1
%      1     0     1     1
%      1     1     0     1
% %      1     1     1     0
%    Hi=[  1     2     4
%      1     3     0
%      3     4     0]
%L=3;

HiUpdate=Hi; %initilize 
ColorMatch=cell(size(G,1),2);
ColoredMap=zeros(size(G,1),size(G,1)); %restor colored matrix
NumOfColorNodeMatch=0;
DegreeOfNode=sum(G);
MaxDegree=max(DegreeOfNode);
MaxDegreeInd=find(DegreeOfNode==MaxDegree);
FirstColoredNode=MaxDegreeInd(1);
ColorMatch{1,1}=FirstColoredNode;% Color number: 1,2,...,L; color oder: 
ColorMatch{1,2}=1;
ColoredMap(FirstColoredNode,FirstColoredNode)=1; % ColoredMap is a square matrix with the i-th diagnoal r meaning that the node i has been colored by color r. 
ColorCandidate=1:L;
ColorCandidate=setdiff(ColorCandidate,1); % to be colored nodes
%%%% update HiUpdate

  PositionColoredNode= HiUpdate==FirstColoredNode;
  HiUpdate(PositionColoredNode)=0;

UsedColor=[];
UsedColor=[UsedColor,1]; %UsedColor=[];
TobeColoredNode=1:size(G,1);
ColoredNode=[];
TobeColoredNode=setdiff(TobeColoredNode,FirstColoredNode);
ColoredNode=[ColoredNode,FirstColoredNode];
NumOfColorNodeMatch=1;
NumOfColorNode=1;

while numel(TobeColoredNode)>0
    MaxNeighborUsedColor=0;
    MaxUsedColorNode=[];
    for iNocolor=TobeColoredNode
        NeiborColor=G(iNocolor,:)*ColoredMap;  %alreadly colored nodes; however, 
        DistinctUsedColor=unique(NeiborColor);
        DistinctUsedColor=setdiff(DistinctUsedColor,[0]);% delete the zero element! good program skill! 
        TempNumOfDistinctUsedColor=length(DistinctUsedColor);
        if TempNumOfDistinctUsedColor>MaxNeighborUsedColor
            NumOfDistinctUsedColor=TempNumOfDistinctUsedColor;
            MaxNeighborUsedColor=NumOfDistinctUsedColor;
            MaxUsedColorNode=iNocolor;
            MaxDistinctUsedColor=DistinctUsedColor;
        end
    end
    if numel(MaxUsedColorNode)>0  % the node that has the maximum differently colored neighboors ?
       if NumOfDistinctUsedColor<L % the maximum number of differently colored neighoors. % then, choose 
          ChooseableUsedColor=setdiff(UsedColor, MaxDistinctUsedColor);%UsedColor=1; 
          if numel(ChooseableUsedColor)>0 % in the used color, choose one different from its neighboors. 
              ColoredMap(MaxUsedColorNode, MaxUsedColorNode)=ChooseableUsedColor(1); %assign the first one;
              CurrentColor=ChooseableUsedColor(1);
          else
              if numel(ColorCandidate)>0  %ColorCandidate=0  the not used colors.  
                   ColoredMap(MaxUsedColorNode, MaxUsedColorNode)=ColorCandidate(1);
                   CurrentColor=ColorCandidate(1);  % choose the first used color
                   ColorCandidate=setdiff(ColorCandidate,ColorCandidate(1));%update the ColorCandidte 
%               else
%                   CurrentColor=UsedColor(1:2);  % could be randomized                   
              end   
          end
       else                           
        %   AlreadyColoredNodes=find(diag(ColoredMap)~=0); % find the indices of all already-used node;
           Kmax=0; % the maximum cardinality of non-fully-colored modes;    Kmax must be large than 1;
           for IndexNonColoredModes=1:size(HiUpdate,1); % HiUpdate_{ij}~=0 means that the node j in mode i is not colored.  
               UncoloredNode=setdiff(HiUpdate(IndexNonColoredModes,:),[0]);  % tempHicurrentMode: the uncovered nodes for mode IndexNoncoloredModes               
     %          UncoloredNode=setdiff(tempHiCurrentMode,AlreadyColoredNodes); % exists non-fully-colored modes
              if numel(UncoloredNode)>0  % if not exist assign ... must exist  !  % If there are unfully colored modes % or maybe zero!
                 IfCurrentnodeBelongHi = setdiff(MaxUsedColorNode,UncoloredNode); %    if the current node is in the uncolored nodes.             
                 if numel(IfCurrentnodeBelongHi)==0    % if exist     
                 Kmaxtemp=numel(setdiff(Hi(IndexNonColoredModes,:),[0])); % |h_i|
                 Kmax=max(Kmaxtemp,Kmax);     
                 end                                 
              end
           end
           %AlreadyColoredNodes   %choose k_{\max}^*
           
%           PositionColoredNode= HiUpdate==MaxUsedColorNode;
%           HiUpdate(PositionColoredNode)=0;
           G(MaxUsedColorNode,:)=0;% cut off all the edges indicent to the multi-colored nodes
           G(:,MaxUsedColorNode)=0;
           CurrentColor=UsedColor(1:Kmax); % arbitrary Kmax colors. 
       end
       
    else   % this is an isolated node
        MaxUsedColorNode=TobeColoredNode(1);
        CurrentColor=UsedColor(1); 
        
    end
        ColoredMap(MaxUsedColorNode, MaxUsedColorNode)=CurrentColor(1); % if k+-colored vertice, no more needed. 
        PositionColoredNode= HiUpdate==MaxUsedColorNode;
        HiUpdate(PositionColoredNode)=0;
        
       NumOfColorNode=NumOfColorNode+1;
       TobeColoredNode=setdiff(TobeColoredNode,MaxUsedColorNode);
       ColoredNode=[ColoredNode,MaxUsedColorNode];
       ColorMatch{NumOfColorNode,1}=MaxUsedColorNode;% Color number: 1,2,...,L
       ColorMatch{NumOfColorNode,2}=CurrentColor;
       NumOfColorNodeMatch=NumOfColorNodeMatch+numel(CurrentColor);
       UsedColor=[UsedColor,CurrentColor];
       UsedColor=unique(UsedColor);
end
end
    


