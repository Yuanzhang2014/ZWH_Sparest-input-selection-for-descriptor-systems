function [V,d,dmaxReturn]=RandMultipleEigenDynamics(n,p,dmax) % n is the dimension, p is the density of V; V is strictly diagonally dominant;dmax is the maximum multiplity
V=zeros(n,n);
for i=1:n
    vcandi=rand(1,n);
    vcandi=vcandi<p;
    vcandi=double(vcandi);
    vcandirowsum=sum(vcandi)-vcandi(i);
    vcandi(i)=vcandirowsum+1; % to make it strictrly diagonallly dominant
    V(i,:)=vcandi;   
end
%% generated multiple eigenvalues
[EigDistribute,dmaxReturn]=RandDistributionOfMultiplity(n,dmax); %for example: EigDistribute=[3,4,2,1]% ��ֲ���������

%%
d=zeros(1,n);
beginindx=0;
distinctval=0;
for i=1:dmax
    for j=1: EigDistribute(i)
     d(beginindx+1+(j-1)*i:beginindx+1+j*i-1)=distinctval; %
     distinctval=distinctval+1;
    end
    beginindx=beginindx+EigDistribute(i)*i;
end
%D=diag(d);






