function r=svdrank(A)
[n1,n2]=size(A);
fsvd=svd(A);
fzero=fsvd<1e-4;
r=min(n1,n2)-sum(fzero);