function r=GrankOfMutiply(NumerMat,StrucMat)% Find the generic rank of a numeric matrix multiplied by a structure matrix
%The StrucMat is formulated as a 0-1 matrix.

[RowNum,ColNum]=size(StrucMat);
%%%%%%%%%%%%%%% Random algorithm

RankList=zeros(2,1);
for i=1:2
    RandomVarible=rand(RowNum,ColNum).*StrucMat;
    RankList(i)=rank(NumerMat*RandomVarible);
end

r=max(RankList);



%%%%%%%%%%%%%%% Determined Algoritm 
%NumOfVarible=sum(sum(StrucMat));


